package com.capg.eis.exception6;

public interface EmployeeService {

}
