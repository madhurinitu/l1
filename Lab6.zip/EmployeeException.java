package com.capg.eis.exception6;

public class EmployeeException {

}
