package com.capgemini.contactbook.dao.test;

import static org.junit.Assert.*;

import org.junit.Test;
import java.util.ConcurrentModificationException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
 
import com.capgemini.contactbook.dao.ContactBookDao;
import com.capgemini.contactbook.dao.ContactBookDaoImpl;
import com.capgemini.contactbook.exceptions.ContactBookException;
 
import com.igate.contactbook.bean.EnquiryBean;
 
 
 
public class Testglobalrecruitment {
ContactBookDaoImpl dao=null;
@Before
public void setUp() {
dao = new ContactBookDaoImpl();
}
 
@After
public void tearDown() {
dao = null;
}
@Test
public void testgetId() {
 
EnquiryBean candidate = new EnquiryBean();
candidate.setContactNo("9908757643");
candidate.setfName("Madhuri");
candidate.setlName("thumala");
candidate.setpDomain("trainee");
candidate.setpLocation("hyd");
 
try {
Integer id = dao.addEnquiry(candidate);
assertNotNull(id);
 
} catch (ContactBookException e) {

}
 
}
@Test
public void testgetEnquiryDetails()
{
ContactBookDao patientDao = new ContactBookDaoImpl();
EnquiryBean p;
 
try {
p=patientDao.getEnquiryDetails(1);
assertEquals("madhuri", p.getfirstName());
} catch (ContactBookException e) {

}
}
}

	