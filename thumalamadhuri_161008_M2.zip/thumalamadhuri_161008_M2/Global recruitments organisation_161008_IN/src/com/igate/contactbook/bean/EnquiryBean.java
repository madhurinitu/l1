package com.igate.contactbook.bean;

public class EnquiryBean {

	private int enqryId;
	private String firstName;
	private String lastName;
	private String contactNo;
	private String pDomain;
	private String pLocation;
	

	public EnquiryBean() {
		
	}

public EnquiryBean(String firstName, String lastName, String contactNo,
			String pDomain, String pLocation) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.contactNo = contactNo;
		this.pDomain = pDomain;
		this.pLocation = pLocation;
	}

public EnquiryBean(int enqryId, String fName, String lName,
			String contactNo, String pDomain, String pLocation) {
		super();
		this.enqryId = enqryId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.contactNo = contactNo;
		this.pDomain = pDomain;
		this.pLocation = pLocation;
	}

public int getEnqryId() {
	return enqryId;
}

public void setEnqryId(int enqryId) {
	this.enqryId = enqryId;
}

public String getfirstName() {
	return firstName;
}

public void setfName(String firstName) {
	this.firstName = firstName;
}

	

	public String getlastName() {
		return lastName;
	}

	public void setlName(String lastName) {
		this.lastName = lastName;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public String getpDomain() {
		return pDomain;
	}

	public void setpDomain(String pDomain) {
		this.pDomain = pDomain;
	}

	public String getpLocation() {
		return pLocation;
	}

	public void setpLocation(String pLocation) {
		this.pLocation = pLocation;
	}
		public String toString() {
			return "ID "+enqryId+
					"\nFirst Name "+firstName+
					"\nLast Name"+lastName+
					"\nContact Number"+contactNo+
					"\npref Domain"+pDomain+
					"\nPreferred Location: "+pLocation;
		
	

	}
}
