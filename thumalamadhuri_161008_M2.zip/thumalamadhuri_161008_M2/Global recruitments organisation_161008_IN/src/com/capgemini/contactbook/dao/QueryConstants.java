package com.capgemini.contactbook.dao;

public interface QueryConstants {

	/**
	 * inserting details of people visiting office into datbase
	 */
	public static final String insertQuery = "insert into enquiry values(enquiries.nextval,?,?,?,?,?)";

	public static final String getIdQuery = "select max(enqryId) from enquiry";

	public static final String getEnquiryDetailsQuery = "select *from enquiry where enqryId=?";

}
