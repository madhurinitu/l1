package lab4;

public class Account {
private long accnum;
 protected static double bal=500;

	public long getAccnum() {
	return accnum;
}

public void setAccnum(long accnum) {
	this.accnum = accnum;
}

public double getBal() {
	return bal;
}

public void setBal(double bal) {
	this.bal = bal;
}
public void deposit(double d)
{
	bal=bal+d;
	System.out.println("bal after deposit");

}
public void withdraw(double o)
{
	bal=bal-o;
	System.out.println("bal after withdrawl");
	
}
double getbal()
{
return bal;
	}

	public static void main(String[] args)
	{
		
//Account a= new Account();
//a.deposit(200);
Person p=new Person("smith",2000);
p.display();
p.deposit(2000);
System.out.println(p.getbal());
Person p1=new Person("Kathy",2000);
p1.display();
p1.withdraw(2000);
System.out.println(p1.getbal());
//System.out.println(a.toString()); 


	}

}
