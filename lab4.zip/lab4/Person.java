package lab4;

class Person extends Account
{
	String Name;
	public String getName()
	{
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	float age;
	private double bal;
	
 public float getAge() {
		return age;
	}

	public void setAge(float age) {
		this.age = age;
	}


	Person(String Name,double bal){
		this.Name=Name;
		this.bal=bal;
		
	}
	void display(){
		System.out.println(Name+ " "+"inital bal=" +bal);
	}
}
