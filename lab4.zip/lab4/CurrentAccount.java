package lab4;

public class CurrentAccount extends Account
{
	double overdraftLimit;
	public static void main(String[] args) {
		
	}

}
