package lab4;

public class SavingsAccount extends Account 
{
final double minimumBalance=500;
public void withdraw(double o)
{
	if(minimumBalance<=500)
	{
		System.out.println(" insufficientamount can't be drawn");
	}
	else
	{
		bal=bal-o;
		System.out.println("bal after withdrawl");
		System.out.println(bal);
	}
}
}

	