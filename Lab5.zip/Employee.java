package com.cg.eis.bean;

public class Employee {
	
	public int EmpId;

	public String EmpName;

	public double Salary;

	public String Designation;

	public String InsuranceScheme;

	public Employee(int EmpId,String EmpName,float Salary,String Designation )


	{

	this.EmpId=EmpId;

	this.EmpName=EmpName;

	this.Salary=Salary;

	this.Designation=Designation;

	 

	}

	 

	 

	public int getEmpId() {

	return EmpId;

	}

	public void setEmpId(int empId) {

	EmpId = empId;

	}

	public String getEmpName() {

	return EmpName;

	}

	public void setEmpName(String empName) {

	EmpName = empName;

	}

	public double getSalary() {

	return Salary;

	}

	public void setSalary(double sal) {

	Salary = sal;

	}

	public String getDesignation() {

	return Designation;

	}

	 

	public void setDesignation(String designation) {

	Designation = designation;

	}

	public String getInsuranceScheme() {

	return InsuranceScheme;

	}

	 

	public void setInsuranceScheme(String insuranceScheme) {

	InsuranceScheme = insuranceScheme;

	}

	 

	
	@Override

	public String toString() {

	return "Employee [EmpId=" + EmpId + ", EmpName=" + EmpName + ", Salary=" + Salary + ", Designation=" + Designation

	+ ", InsuranceScheme=" + InsuranceScheme + "]";

	}

	 

	public void CheckInsuranceScheme()

	{

	if ((Salary>5000)&&(Salary<20000)&&(Designation.equals("system associate")))

	{

	InsuranceScheme="Scheme C";

	}

	else if((Salary>=20000)&&(Salary<40000)&&(Designation.equals("programmer")))

	{

	InsuranceScheme="Scheme B";

	 
	

	}

	else if((Salary>=40000)&&(Designation.equals("manager")))

	{

	InsuranceScheme="Scheme A";

	}

	else if((Salary<5000)&&(Designation.equals("clerk")))

	{

	InsuranceScheme="No Scheme";

	}

	else {

	System.out.println("Invalid Employee Details");

	}

	}

	 

	}

	


