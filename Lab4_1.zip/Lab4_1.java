package com.capg4;

 

import java.util.Random;

 

public class Lab4_1 {

 

public static void main(String[] args) {

Person person1=new Person("smith",39);

Person person2=new Person("kathy",20);

Account smith = new Account();

Account kathy = new Account();

Random random=new Random();

smith.setAccNum(Math.abs(random.nextLong()));

smith.setBalance(2000);

smith.setAccHolder(person1);

kathy.setAccNum(Math.abs(random.nextLong()));

kathy.setBalance(3000);

System.out.println("smiths initial balance is:"+smith.getBalance());

System.out.println("kathy initial balance is:"+kathy.getBalance());

kathy.setAccHolder(person2);

smith.deposit(2000);

 

System.out.println("smiths updated balance is:"+smith.getBalance());

kathy.withdraw(2000);

System.out.println("kathy updated balance is:"+kathy.getBalance());

 

}

 

}